package fca.imple.compras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComprasApplicationTests {

	@Test
	void contextLoads() {
	}

}
